//
//  ViewController.h
//  EditDemo
//
//  Created by iHope on 13-9-17.
//  Copyright (c) 2013年 iHope. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EditImageView.h"

@interface ViewController : UIViewController<EditImageViewDelegate>

@end
